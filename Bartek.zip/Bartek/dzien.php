<?php

$i=2;
$b=100;

for($i = 2; $i <= $b; $i += 2)
echo ' '.$i;




?>