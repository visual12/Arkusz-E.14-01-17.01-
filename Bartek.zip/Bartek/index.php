<html>
<head>
<title>Jakiś tytuł
</title>
<meta charset="utf-8">
</head>
<body>
<h1>Lista uczniów</h1>

<?php
$servername = "mysql.cba.pl";
$username = "kloceklego";
$password = "Klocek12";
$dbase = "kloceklego";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbase);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

$sql = "SELECT id, imie, nazwisko FROM uczniowie";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " " . $row["imie"]. " " . $row["nazwisko"]." ". $row["klasa"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?> 

</body>
</html>